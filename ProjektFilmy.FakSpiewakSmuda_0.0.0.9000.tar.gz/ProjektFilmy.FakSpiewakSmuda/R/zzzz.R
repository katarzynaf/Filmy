.onAttach <- function(libname, pkgname) {
      packageStartupMessage("Welcome to our package. Have fun!")
}
